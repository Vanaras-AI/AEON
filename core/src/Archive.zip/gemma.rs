use candle_core::{Device, Tensor, DType};
use candle_nn::VarBuilder;
use crate::gemma3::{Config, Model};
use tokenizers::Tokenizer;
use candle_transformers::generation::LogitsProcessor;
use anyhow::{Error, Result};
use std::path::Path;

pub struct Oracle {
    model: Model,
    tokenizer: Tokenizer,
    device: Device,
    logits_processor: LogitsProcessor,
}

impl Oracle {
    pub fn new() -> Result<Self> {
        let candidates = vec![
            "../governance_model/fused_model", // From core/
            "governance_model/fused_model",    // From root/
            "fused_model",                     // Local
        ];

        let base_path = candidates.iter()
            .find(|p| Path::new(p).join("model.safetensors").exists())
            .ok_or_else(|| Error::msg("Gemma model not found. Run 'python merge_adapter.py' in governance_model/"))?;

        let base = Path::new(base_path);
        let model_path = base.join("model.safetensors");
        let config_path = base.join("config.json");
        let tokenizer_path = base.join("tokenizer.json");

        println!("🧠 [GEMMA] Found model at: {}", base_path);

        let config_str = std::fs::read_to_string(config_path)?;
        let config: Config = serde_json::from_str(&config_str)?;

        // Use Metal (Mac) if available
        let device = Device::new_metal(0).unwrap_or(Device::Cpu);
        
        // Load weights
        let vb = unsafe { VarBuilder::from_mmaped_safetensors(&[model_path], DType::F32, &device)? };
        let model = Model::new(false, &config, vb)?;
        
        let tokenizer = Tokenizer::from_file(tokenizer_path).map_err(Error::msg)?;

        let logits_processor = LogitsProcessor::new(299792458, Some(0.7), Some(0.9));

        Ok(Self {
            model,
            tokenizer,
            device,
            logits_processor,
        })
    }

    pub fn infer(&mut self, prompt: &str) -> Result<String> {
        eprintln!("DEBUG: Entering infer");
        // Format prompt (Gemma 3 Instruct format) - Confirmed via README.md
        let formatted_prompt = format!(
            "<start_of_turn>user\nAssess compliance risk for the following scenario.\n\nInput:\n{}<end_of_turn>\n<start_of_turn>model\n",
            prompt
        );
        eprintln!("DEBUG: Prompt formatted");

        let tokens = self.tokenizer.encode(formatted_prompt, true).map_err(Error::msg)?;
        eprintln!("DEBUG: Tokenized");
        let input_ids = tokens.get_ids();
        let mut pos = 0;
        let mut input_tensor = Tensor::new(input_ids, &self.device)?.unsqueeze(0)?;
        let mut response_tokens = Vec::new();
        eprintln!("🧠 [GEMMA] Starting inference loop...");

        for i in 0..128 {
            let seq_len = input_tensor.dim(1)?;
            let logits = self.model.forward(&input_tensor, pos)?;
            pos += seq_len;
            
            // Get logits for the last token
            let logits = logits.squeeze(0)?; // [seq_len, vocab_size]
            let logits = if logits.dim(0)? == 1 {
                logits.get(0)?
            } else {
                logits.get(seq_len - 1)?
            };
            
            let next_token_id = self.logits_processor.sample(&logits)?;
            
            
            // Check for EOS (Gemma normally uses 1 or 107, config says eos_token_id: 1)
            if next_token_id == 1 || next_token_id == 107 { 
                println!(); // Newline after dots
                break;
            }
            
            response_tokens.push(next_token_id);
            input_tensor = Tensor::new(&[next_token_id], &self.device)?.unsqueeze(0)?;
        }
        println!(); // ensure newline if max tokens reached

        let output = self.tokenizer.decode(&response_tokens, true).map_err(Error::msg)?;
        Ok(output)
    }
}
